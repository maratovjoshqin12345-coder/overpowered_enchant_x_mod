# Overpowered Enchant X & Hardcore Plus (overpowered_enchant_x)

## 🌟 Mod Xususiyatlari:
1. ⚔️ **10-Darajali Barcha Sehrlar (Level X)**: Sandon va stol orqali har qanday enchantni 10-darajagacha oshirish mumkin!
2. 🛡️ **Bronyalarga Barcha Enchantlar Mosligi**: Protection X, Fire Protection X, Blast Protection X bir vaqtning o'zida bitta bronyaga qo'yiladi.
3. 🔨 **Sandon (Anvil) 10-Daraja Cheklovi**: Hech qachon 10 darajadan ko'p EXP so'ramaydi va "Too Expensive" xatosi yo'q!
4. 🧪 **/exp Buyrug'i**:
   - `/exp 10` -> 10-darajali EXP Shishasi beradi.
   - `/exp 20` -> 20-darajali EXP Shishasi beradi.
   - `/exp 30` -> 30-darajali EXP Shishasi beradi.
   - `/exp 40` -> 40-darajali EXP Shishasi beradi.
   - Shishani bosganda darhol ko'rsatilgan darajani qo'shadi!
5. 🧿 **Totem of Undying 64 Stak**: Totemlar 64 tagacha yig'iladi va o'lganda faqat 1 donasi sarflanadi.
6. ❤️ **2 Qator Jon (40 HP)**: O'yinchining bazaviy joni 40 HP ga oshirilgan.
7. 👁️ **Doimiy Tunda Ko'rish (Night Vision)** & 🔥 **Olovga Qarshilik (Fire Resistance)**.

## Qanday ishga tushirish kerak (IntelliJ IDEA):
1. Ushbu ZIP faylni oching (Unzip).
2. IntelliJ IDEA dasturida `File -> Open` orqali ushbu papkani tanlang.
3. Gradle yuklanishini kuting.
4. O'ng tomondagi `Gradle` panelidan: `Tasks -> fabric -> runClient` tugmasini bosing!
