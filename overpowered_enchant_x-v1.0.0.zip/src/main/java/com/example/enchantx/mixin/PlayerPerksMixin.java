package com.example.enchantx.mixin;

import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayerEntity.class)
public class PlayerPerksMixin {

    /**
     * Har bir o'yinchiga 2 qator jon (40 HP) va doimiy Tunda Ko'rish (Night Vision) + Olovga Qarshilik (Fire Resistance) berish
     */
    @Inject(method = "tick", at = @At("TAIL"))
    private void applyHardcorePerks(CallbackInfo ci) {
        ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

        // 1. Maksimal jon: 40 HP (Minecraft 1.21 Yarn: EntityAttributes.MAX_HEALTH)
        var healthAttr = player.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (healthAttr != null && healthAttr.getBaseValue() < 40.0) {
            healthAttr.setBaseValue(40.0);
            if (player.getHealth() < 40.0f) {
                player.setHealth(40.0f);
            }
        }

        // 2. Doimiy Tunda ko'rish (Night Vision)
        player.addStatusEffect(new StatusEffectInstance(
            StatusEffects.NIGHT_VISION,
            600, // 30 soniya yangilanib turadi
            0,
            true, // ambient (belgisiz)
            false, // zarrachalar ko'rinmaydi
            false // ikonka ekranni to'smaydi
        ));

        // 3. Doimiy Olovga Qarshilik (Fire Resistance)
        player.addStatusEffect(new StatusEffectInstance(
            StatusEffects.FIRE_RESISTANCE,
            600,
            0,
            true,
            false,
            false
        ));
    }
}
