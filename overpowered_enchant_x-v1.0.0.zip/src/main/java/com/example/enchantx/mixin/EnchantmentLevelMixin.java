package com.example.enchantx.mixin;

import com.example.enchantx.OverpoweredEnchantXHardcorePlus;
import net.minecraft.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Enchantment.class)
public class EnchantmentLevelMixin {

    /**
     * Barcha enchantlarning maksimal darajasini 10 (Level X) qilib belgilaydi
     */
    @Inject(method = "getMaxLevel", at = @At("HEAD"), cancellable = true)
    public void overrideMaxLevel(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(OverpoweredEnchantXHardcorePlus.MAX_ENCHANT_LEVEL);
    }
}
