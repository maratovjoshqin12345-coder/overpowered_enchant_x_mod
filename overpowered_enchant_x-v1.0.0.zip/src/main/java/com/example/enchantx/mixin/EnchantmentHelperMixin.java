package com.example.enchantx.mixin;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EnchantmentHelper.class)
public class EnchantmentHelperMixin {

    /**
     * Barcha sehrlarni bir-biri bilan 100% mos (compatible) qiladi (Protection, Fire Prot, Blast Prot birga qo'yish mumkin)
     */
    @Inject(method = "isCompatible", at = @At("HEAD"), cancellable = true)
    private static void makeAllEnchantmentsCompatible(
            RegistryEntry<Enchantment> first,
            RegistryEntry<Enchantment> second,
            CallbackInfoReturnable<Boolean> cir
    ) {
        cir.setReturnValue(true);
    }
}
