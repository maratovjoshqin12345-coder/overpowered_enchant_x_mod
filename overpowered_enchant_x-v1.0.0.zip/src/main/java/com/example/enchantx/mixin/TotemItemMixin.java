package com.example.enchantx.mixin;

import net.minecraft.item.Item;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Item.class)
public class TotemItemMixin {

    /**
     * O'lmaslik Totemini (Totem of Undying) 64 tagacha stak qilish imkoniyati
     */
    @Inject(method = "getMaxCount", at = @At("HEAD"), cancellable = true)
    private void makeTotemStackable(CallbackInfoReturnable<Integer> cir) {
        Item item = (Item) (Object) this;
        if (item == Items.TOTEM_OF_UNDYING) {
            cir.setReturnValue(64);
        }
    }
}
