package com.example.enchantx.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.Property;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AnvilScreenHandler.class)
public abstract class AnvilScreenHandlerMixin {

    @Shadow
    @Final
    private Property levelCost;

    /**
     * Sandon (Anvil) 40 darajadan oshganda "Too Expensive" deb qulflab qo'yishini bekor qiladi
     */
    @ModifyConstant(method = "updateResult", constant = @Constant(intValue = 40))
    private int removeTooExpensiveCap(int originalLimit) {
        return Integer.MAX_VALUE;
    }

    /**
     * Sandon daraja narxi HECH QACHON 10-darajadan oshmaydi (Maksimal 10 EXP so'raydi)
     */
    @Inject(method = "updateResult", at = @At("TAIL"))
    private void capAnvilCostAtTen(CallbackInfo ci) {
        if (this.levelCost.get() > 10) {
            this.levelCost.set(10);
        }
    }

    /**
     * O'yinchiga har doim sandondan buyumni olishga ruxsat berish (to'g'ri parametrlar bilan)
     */
    @Inject(method = "canTakeOutput", at = @At("HEAD"), cancellable = true)
    private void allowTakeOutput(PlayerEntity player, boolean present, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }
}
