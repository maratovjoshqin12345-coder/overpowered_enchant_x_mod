package com.example.enchantx.command;

import com.example.enchantx.item.ModItems;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public class ExpCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                CommandManager.literal("exp")
                    .executes(context -> {
                        ServerPlayerEntity player = context.getSource().getPlayer();
                        if (player != null) {
                            player.sendMessage(Text.literal("§6§l[EXP Tizimi] §eQuyidagi darajalardan birini tanlang:\n§a/exp 10 §7- 10 darajani shishaga solish\n§a/exp 20 §7- 20 darajani shishaga solish\n§a/exp 30 §7- 30 darajani shishaga solish\n§a/exp 40 §7- 40 darajani shishaga solish"), false);
                        }
                        return 1;
                    })
                    .then(
                        CommandManager.argument("amount", IntegerArgumentType.integer(10, 40))
                            .executes(context -> {
                                int amount = IntegerArgumentType.getInteger(context, "amount");
                                ServerPlayerEntity player = context.getSource().getPlayer();
                                if (player == null) return 0;

                                // Faqat 10, 20, 30, 40 darajalar ruxsat etiladi
                                if (amount != 10 && amount != 20 && amount != 30 && amount != 40) {
                                    player.sendMessage(Text.literal("§c❌ Xatolik! Faqat 10, 20, 30 yoki 40 darajalarni shishaga aylantira olasiz!"), false);
                                    return 0;
                                }

                                if (player.experienceLevel < amount) {
                                    player.sendMessage(Text.literal("§c❌ Sizda yetarli tajriba darajasi (EXP) yo'q! Sizda: §e" + player.experienceLevel + " Lvl§c, kerak: §e" + amount + " Lvl"), false);
                                    return 0;
                                }

                                // O'yinchidan darajani olib tashlash
                                player.addExperienceLevels(-amount);

                                // Shishani berish
                                ItemStack bottle;
                                switch (amount) {
                                    case 10 -> bottle = new ItemStack(ModItems.EXP_BOTTLE_10);
                                    case 20 -> bottle = new ItemStack(ModItems.EXP_BOTTLE_20);
                                    case 30 -> bottle = new ItemStack(ModItems.EXP_BOTTLE_30);
                                    default -> bottle = new ItemStack(ModItems.EXP_BOTTLE_40);
                                }

                                if (!player.getInventory().insertStack(bottle)) {
                                    player.dropItem(bottle, false);
                                }

                                player.getWorld().playSound(
                                    null,
                                    player.getX(),
                                    player.getY(),
                                    player.getZ(),
                                    SoundEvents.BLOCK_BREWING_STAND_BREW,
                                    SoundCategory.PLAYERS,
                                    1.0f,
                                    1.2f
                                );

                                player.sendMessage(Text.literal("§a✅ " + amount + "-darajalik EXP Shishasi tayyorlandi va inventaringizga qo'shildi!"), false);
                                return 1;
                            })
                    )
            );
        });
    }
}
