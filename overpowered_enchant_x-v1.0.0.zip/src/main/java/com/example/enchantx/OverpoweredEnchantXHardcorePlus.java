package com.example.enchantx;

import com.example.enchantx.command.ExpCommand;
import com.example.enchantx.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OverpoweredEnchantXHardcorePlus implements ModInitializer {
    public static final String MOD_ID = "overpowered_enchant_x";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Maksimal Enchant darajasi
    public static final int MAX_ENCHANT_LEVEL = 10;

    @Override
    public void onInitialize() {
        LOGGER.info("🔥 {} (Fabric 1.21) muvaffaqiyatli ishga tushdi!", MOD_ID);
        ModItems.registerModItems();
        ModBlocks.registerModBlocks();
        ExpCommand.register();
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
}
