package com.example.enchantx.item;

import com.example.enchantx.OverpoweredEnchantXHardcorePlus;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Rarity;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
    // 4 xil EXP Shishalari (10, 20, 30, 40 darajali)
    public static final Item EXP_BOTTLE_10 = registerItem("exp_bottle_10", new ExpBottleItem(10, new Item.Settings().maxCount(64).rarity(Rarity.UNCOMMON)));
    public static final Item EXP_BOTTLE_20 = registerItem("exp_bottle_20", new ExpBottleItem(20, new Item.Settings().maxCount(64).rarity(Rarity.RARE)));
    public static final Item EXP_BOTTLE_30 = registerItem("exp_bottle_30", new ExpBottleItem(30, new Item.Settings().maxCount(64).rarity(Rarity.EPIC)));
    public static final Item EXP_BOTTLE_40 = registerItem("exp_bottle_40", new ExpBottleItem(40, new Item.Settings().maxCount(64).rarity(Rarity.EPIC)));

    public static final Item GOD_ARMOR_CHESTPLATE = registerItem("god_armor_chestplate", new Item(new Item.Settings()));
    public static final Item INFINITY_BLADE_X = registerItem("infinity_blade_x", new SwordItem(ToolMaterials.NETHERITE, new Item.Settings()));

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, OverpoweredEnchantXHardcorePlus.id(name), item);
    }

    public static void registerModItems() {
        OverpoweredEnchantXHardcorePlus.LOGGER.info("Registering Items for " + OverpoweredEnchantXHardcorePlus.MOD_ID);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(EXP_BOTTLE_10);
            entries.add(EXP_BOTTLE_20);
            entries.add(EXP_BOTTLE_30);
            entries.add(EXP_BOTTLE_40);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(GOD_ARMOR_CHESTPLATE);
            entries.add(INFINITY_BLADE_X);
        });
    }
}
