package com.example.enchantx.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import java.util.List;

public class ExpBottleItem extends Item {
    private final int expLevels;

    public ExpBottleItem(int expLevels, Settings settings) {
        super(settings);
        this.expLevels = expLevels;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient) {
            // O'yinchiga darajani to'g'ridan-to'g'ri qo'shish
            user.addExperienceLevels(this.expLevels);

            world.playSound(
                null,
                user.getX(),
                user.getY(),
                user.getZ(),
                SoundEvents.ENTITY_PLAYER_LEVELUP,
                SoundCategory.PLAYERS,
                1.0f,
                1.0f
            );

            user.sendMessage(Text.literal("§a⚡ +" + this.expLevels + " Tajriba Darajasi berildi! Yangi darajangiz: §e" + user.experienceLevel + " Lvl"), true);
        }

        if (!user.getAbilities().creativeMode) {
            stack.decrement(1);
        }

        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.literal("§6⚡ Ishlatilganda: §a+" + this.expLevels + " Daraja EXP beradi"));
        tooltip.add(Text.literal("§7Sichqonchaning o'ng tugmasini bosing"));
        super.appendTooltip(stack, context, tooltip, type);
    }
}
